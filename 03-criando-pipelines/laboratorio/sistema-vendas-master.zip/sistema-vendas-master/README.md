## Sistema de Vendas
Repositorio que armazena o codigo fonte do Sistema de Vendas

#### Build local
```
mvn clean package
```
